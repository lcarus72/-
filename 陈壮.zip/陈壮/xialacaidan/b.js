$("#header").find(".box-l").mouseover(function(){
    $("#header").find(".box1").css("display","block")
})
$("#header").find(".box-l").mouseout(function(){
    $("#header").find(".box1").css("display","none")
})


$("#header").find(".box-c").mouseover(function(){
    $("#header").find(".box2").css("display","block")
})
$("#header").find(".box-c").mouseout(function(){
    $("#header").find(".box2").css("display","none")
})


$("#header").find(".box-r").mouseover(function(){
    $("#header").find(".box3").css("display","block")
})
$("#header").find(".box-r").mouseout(function(){
    $("#header").find(".box3").css("display","none")
})


$("#header").find(".box-o").mouseover(function(){
    $("#header").find(".box4").css("display","block")
})
$("#header").find(".box-o").mouseout(function(){
    $("#header").find(".box4").css("display","none")
})