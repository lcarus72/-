
    //获取元素
    var ospan=document.getElementById("bbb")
   var oul=document.querySelector("ul")
   var ali=document.querySelectorAll("li")



    //给点击事件加的状态
   var onOff=0;
   //点击事件
   ospan.onclick=function(eve){
       //阻止冒泡
        var e=eve||window.event;
        if(e.stopPropagation){
				e.stopPropagation()
		}else{
				e.cancelBubble = true;
        }
        
        if(onOff==0){
            oul.style.display="block";
            setActive()
            onOff=1;
        }else{
            oul.style.display="none"
            onOff=0;
        }
   }  
   //点击空白的事件
    document.onclick=function(){
        oul.style.display="none";
        onOff=0;
    }

    for(var i=0;i<ali.length;i++){
        ali[i].index=i;
        ali[i].onmouseover=function(){
            index=this.index
            setActive()
        }
        ali[i].onclick=function(){
            ospan.innerHTML=this.innerHTML;
            index=this.index;
        }
    }


    document.onkeydown=function(eve){
        if(oul.style.display === "none") return;

        var e = eve || window.event
        var code = e.keyCode || e.which;
        
        if(code === 38){
//				计算索引
				if(index == 0){
					index = 0
				}else{
					index--
				}
//				根据索引设置当前项和span内容
				setActive()
				ospan.innerHTML = ali[index].innerHTML
            }
            
            if(code === 40){
//				计算索引
				if(index == ali.length-1){
					index = ali.length-1
				}else{
					index++;
                }
                
                setActive()
				ospan.innerHTML = ali[index].innerHTML
            }
            
            if(code==13){
                oul.style.display="none";
                ospan.innerHTML = ali[index].innerHTML
                onOff=0;
            }
    }


    function setActive(){
			for(var j=0;j<ali.length;j++){
				ali[j].className = "";
			}
			ali[index].className = "active";
		}
