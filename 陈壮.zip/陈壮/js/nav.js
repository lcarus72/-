$(".li1").children("span").mouseover(function(){
    $(".erji").css("display","block")
    $(".li1").css("background","#b8a07a")
})
$(".li1").children("span").mouseout(function(){
    $(".erji").css("display","none")
    $(".li1").css("background","#fff")
})
$(".li2").children("span").mouseover(function(){
    $(".erji2").css("display","block")
    $(".li2").css("background","#b8a07a")
})
$(".li2").children("span").mouseout(function(){
    $(".erji2").css("display","none")
    $(".li2").css("background","#fff")
})

   
