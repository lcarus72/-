var oli=document.querySelectorAll(".mainb-2 ol li")
var uli=document.querySelectorAll(".mainb-2 ul li")

var index=0;
for(var i=0;i<uli.length;i++){
    uli[i].index=i;
    uli[i].onmouseover=function(){
        index=this.index;
        for(var j=0;j<oli.length;j++){
            uli[j].className=""
        }
        this.className="cake"
        oli[index].style.display="block"
    }
    uli[i].onmouseout=function(){
        index=this.index;
        for(var k=0;k<oli.length;k++){
            uli[k].className=""
        }
        oli[index].style.display="none"
    }
    oli[i].onmouseover=function(){
        this.style.display="block"
    }
    oli[i].onmouseout=function(){
        this.style.display="none"
    }
}