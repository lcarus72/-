function Banner(){
    //1获取元素
    this.imgbox = document.querySelector(".imgbox")
    this.img = document.querySelectorAll(".imgbox a")
    this.left = document.getElementById("left")
    this.right = document.getElementById("right")

    this.index=0;
    //2完善布局
    this.init()
}
Banner.prototype.init=function(){
    //正在完善布局
    this.imgbox.style.width = this.img.length * this.img[0].offsetWidth + "px";
    //绑定事件
    this.addEvent()
}
Banner.prototype.addEvent=function(){
    var that=this;
    //开始绑定事件
    this.right.onclick=function(){
        //触发事件
        //右按钮计算索引
        that.changeIndex("r")
    }
    this.left.onclick=function(){
        //触发事件
        //左按钮计算索引
        that.changeIndex("l")
    }
}
Banner.prototype.changeIndex=function(type){
    if(type == "r"){
        //				右按钮开始改变索引...
                        if(this.index == this.img.length-1){
                            this.imgbox.style.left = 0;
                            this.index = 1;
                        }else{
                            this.index++;
                        }
                    }else{
        //				左按钮开始改变索引...
                        if(this.index == 0){
                            this.imgbox.style.left = -(this.img.length-1) * this.img[0].offsetWidth + "px"
                            this.index = this.img.length-1-1;
                        }else{
                            this.index--;
                        }
                }
                //5.根据索引显示对应图片
            this.display()
}
Banner.prototype.display = function(){
    //			显示
                console.log(this.index)
                move(this.imgbox,{left:-this.index*this.img[0].offsetWidth})
            }
            
            new Banner();