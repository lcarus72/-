$(".banner2").banner({
    items:$(".banner2 .imgbox").children(),
    left:$(".banner2 #left"),
    right:$(".banner2 #right"),
    
    list:true,
    autoPlay:false
});